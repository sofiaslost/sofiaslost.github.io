export default interface VoteStatus {
	timeToEnd: number;
	yesVotes: number;
	noVotes: number;
}
