enum MuteState {
	Temp = 0,
	Perma = 1,
	Unmuted = 2
}

export default MuteState;
