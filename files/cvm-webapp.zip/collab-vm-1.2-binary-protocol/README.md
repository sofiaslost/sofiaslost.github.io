# collab-vm-1.2-binary-protocol

Common schema for the CollabVM 1.2 Binary Protocol