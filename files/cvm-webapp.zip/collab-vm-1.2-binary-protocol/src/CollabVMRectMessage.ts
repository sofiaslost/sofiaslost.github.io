export interface CollabVMRectMessage {
    x: number;
    y: number;
    data: Uint8Array;
}